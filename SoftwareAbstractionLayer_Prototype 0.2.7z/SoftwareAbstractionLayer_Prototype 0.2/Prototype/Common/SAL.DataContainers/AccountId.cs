﻿/*********************************************************
 * Author: Danut Prisacaru
 * 
 * Application Architect
 * 
*********************************************************/

using System;
using System.Collections.Generic;
using System.Text;

namespace SAL.DataContainers
{
    public class AccountId
    {
        public String ClearingId;
    }
}
